
# MatrixResponseDurations

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



