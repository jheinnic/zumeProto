
# Geocoderesponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**features** | [**List&lt;GeocoderesponseFeatures&gt;**](GeocoderesponseFeatures.md) |  |  [optional]
**bbox** | **List&lt;Double&gt;** | Contains the minimum bounding box of all features. |  [optional]
**info** | [**GeocoderesponseInfo**](GeocoderesponseInfo.md) |  |  [optional]



