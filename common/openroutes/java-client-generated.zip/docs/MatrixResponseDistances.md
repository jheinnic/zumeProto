
# MatrixResponseDistances

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



