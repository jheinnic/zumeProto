
# GeocoderesponseFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**geometry** | [**GeocoderesponseGeometry**](GeocoderesponseGeometry.md) |  |  [optional]
**properties** | [**GeocoderesponseProperties**](GeocoderesponseProperties.md) |  |  [optional]



