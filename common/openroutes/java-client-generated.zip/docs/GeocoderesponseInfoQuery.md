
# GeocoderesponseInfoQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**query** | **String** |  |  [optional]
**location** | **List&lt;Double&gt;** |  |  [optional]
**limit** | **Long** |  |  [optional]



