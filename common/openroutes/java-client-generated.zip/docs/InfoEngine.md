
# InfoEngine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** | Backend version used for the request. |  [optional]
**buildDate** | **String** | Build date of the used backend version |  [optional]



