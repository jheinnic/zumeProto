
# MatrixResponseInfoQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**profile** | **String** |  |  [optional]
**locations** | [**List&lt;List&lt;Double&gt;&gt;**](List.md) |  |  [optional]
**sources** | **List&lt;String&gt;** |  |  [optional]
**destinations** | **List&lt;String&gt;** |  |  [optional]
**metrics** | **List&lt;String&gt;** |  |  [optional]
**optimized** | **Boolean** |  |  [optional]



