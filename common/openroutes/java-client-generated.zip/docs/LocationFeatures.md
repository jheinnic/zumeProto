
# LocationFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**geometry** | [**LocationFeaturesGeometry**](LocationFeaturesGeometry.md) |  |  [optional]
**properties** | [**LocationFeaturesProperties**](LocationFeaturesProperties.md) |  |  [optional]



