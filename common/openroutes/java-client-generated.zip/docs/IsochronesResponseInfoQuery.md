
# IsochronesResponseInfoQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mode** | **String** |  |  [optional]
**rangeType** | **String** |  |  [optional]
**range** | **Long** |  |  [optional]
**interval** | **Long** |  |  [optional]
**locations** | [**List&lt;List&lt;Double&gt;&gt;**](List.md) |  |  [optional]



