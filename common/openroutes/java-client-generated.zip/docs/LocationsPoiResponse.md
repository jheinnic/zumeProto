
# LocationsPoiResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**features** | [**List&lt;LocationFeatures&gt;**](LocationFeatures.md) |  |  [optional]
**bbox** | **List&lt;Double&gt;** | Contains the minimum bounding box of all features. |  [optional]
**info** | [**LocationsPoiResponseInfo**](LocationsPoiResponseInfo.md) |  |  [optional]



