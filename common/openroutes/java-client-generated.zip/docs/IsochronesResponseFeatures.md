
# IsochronesResponseFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**geometry** | [**IsochronesResponseGeometry**](IsochronesResponseGeometry.md) |  |  [optional]
**type** | **String** |  |  [optional]
**properties** | [**IsochronesResponseProperties**](IsochronesResponseProperties.md) |  |  [optional]



