
# Routeresponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**routes** | [**List&lt;RouteresponseRoutes&gt;**](RouteresponseRoutes.md) |  |  [optional]
**info** | [**RouteresponseInfo**](RouteresponseInfo.md) |  |  [optional]



