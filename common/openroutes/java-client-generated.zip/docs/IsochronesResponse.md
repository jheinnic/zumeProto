
# IsochronesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**features** | [**List&lt;IsochronesResponseFeatures&gt;**](IsochronesResponseFeatures.md) |  |  [optional]
**bbox** | **List&lt;Double&gt;** | Contains the minimum bounding box of all features. |  [optional]
**info** | [**IsochronesResponseInfo**](IsochronesResponseInfo.md) |  |  [optional]



