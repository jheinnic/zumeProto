
# LocationsPoiResponseInfoQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filter** | [**LocationsPoiResponseInfoQueryFilter**](LocationsPoiResponseInfoQueryFilter.md) |  |  [optional]
**radius** | **Long** |  |  [optional]
**limit** | **Long** |  |  [optional]



