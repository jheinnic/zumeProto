
# RouteresponseInfoQuery

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**profile** | **String** |  | 
**preference** | **String** |  |  [optional]
**coordinates** | [**List&lt;List&lt;Double&gt;&gt;**](List.md) |  | 
**language** | **String** |  |  [optional]
**units** | **String** |  |  [optional]
**geometry** | **Boolean** |  |  [optional]
**geometryFormat** | **String** |  | 
**instructionsFormat** | **String** |  |  [optional]
**instructions** | **Boolean** |  |  [optional]
**elevation** | **Boolean** |  |  [optional]
**options** | **String** |  |  [optional]



