
# LocationFeaturesGeometry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**coordinates** | **List&lt;Double&gt;** |  |  [optional]



