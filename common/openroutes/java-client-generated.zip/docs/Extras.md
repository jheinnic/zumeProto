
# Extras

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**steepness** | [**ExtrasProperty**](ExtrasProperty.md) |  |  [optional]
**suitability** | [**ExtrasProperty**](ExtrasProperty.md) |  |  [optional]
**surface** | [**ExtrasProperty**](ExtrasProperty.md) |  |  [optional]
**waycategory** | [**ExtrasProperty**](ExtrasProperty.md) |  |  [optional]
**waytype** | [**ExtrasProperty**](ExtrasProperty.md) |  |  [optional]
**tollways** | [**ExtrasProperty**](ExtrasProperty.md) |  |  [optional]
**traildifficulty** | [**ExtrasProperty**](ExtrasProperty.md) |  |  [optional]



