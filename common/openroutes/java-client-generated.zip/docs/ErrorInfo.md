
# ErrorInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** |  |  [optional]
**timestamp** | **Long** |  |  [optional]



