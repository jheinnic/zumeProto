
# ProfileParamsWeightings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**level** | [**LevelEnum**](#LevelEnum) |  |  [optional]


<a name="LevelEnum"></a>
## Enum: LevelEnum
Name | Value
---- | -----
NUMBER_0 | 0l
NUMBER_1 | 1l
NUMBER_2 | 2l
NUMBER_3 | 3l



