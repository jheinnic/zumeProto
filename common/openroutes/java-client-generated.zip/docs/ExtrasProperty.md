
# ExtrasProperty

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**values** | [**List&lt;List&lt;Double&gt;&gt;**](List.md) | Broken down by way_points. |  [optional]
**summary** | [**List&lt;SummaryObject&gt;**](SummaryObject.md) | Broken down by information category values. |  [optional]



