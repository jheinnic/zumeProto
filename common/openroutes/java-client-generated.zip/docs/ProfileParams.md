
# ProfileParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**length** | **Double** |  |  [optional]
**width** | **Double** |  |  [optional]
**height** | **Double** |  |  [optional]
**axleload** | **Double** |  |  [optional]
**weight** | **Double** |  |  [optional]
**hazmat** | **Boolean** |  |  [optional]
**weightings** | [**ProfileParamsWeightings**](ProfileParamsWeightings.md) |  |  [optional]
**restrictions** | [**ProfileParamsRestrictions**](ProfileParamsRestrictions.md) |  |  [optional]



