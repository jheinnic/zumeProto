
# Filter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categoryGroupIds** | **List&lt;Long&gt;** |  |  [optional]
**catoegoryIds** | **List&lt;Long&gt;** |  |  [optional]



