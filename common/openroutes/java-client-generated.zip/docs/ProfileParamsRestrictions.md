
# ProfileParamsRestrictions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gradient** | **Long** |  |  [optional]



