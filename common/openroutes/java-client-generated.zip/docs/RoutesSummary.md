
# RoutesSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**distance** | **Double** | Total route distance in specified units. |  [optional]
**duration** | **Double** | Total duration in seconds. |  [optional]
**ascent** | **Double** | Total ascent in meters. |  [optional]
**descent** | **Double** | Total descent in meters. |  [optional]
**avgspeed** | **Double** | Total average speed in km/h |  [optional]



