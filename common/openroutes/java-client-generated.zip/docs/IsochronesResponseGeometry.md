
# IsochronesResponseGeometry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**coordinates** | [**List&lt;List&lt;Double&gt;&gt;**](List.md) |  |  [optional]
**type** | **String** |  |  [optional]



