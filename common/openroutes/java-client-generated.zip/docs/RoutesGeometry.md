
# RoutesGeometry

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**coordinates** | [**GeometryCoordinates**](GeometryCoordinates.md) |  |  [optional]



