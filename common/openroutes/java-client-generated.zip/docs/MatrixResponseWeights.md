
# MatrixResponseWeights

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



