
# Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | [**ErrorError**](ErrorError.md) |  |  [optional]
**info** | [**ErrorInfo**](ErrorInfo.md) |  |  [optional]



