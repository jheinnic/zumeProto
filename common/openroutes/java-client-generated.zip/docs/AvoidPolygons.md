
# AvoidPolygons

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  |  [optional]
**coordinates** | [**List&lt;List&lt;Double&gt;&gt;**](List.md) |  |  [optional]



