
# SummaryObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Long** | [Value](https://github.com/GIScience/openrouteservice-docs#routing-response) of a info category. |  [optional]
**distance** | **Long** | Cumulative distance of this value. |  [optional]
**amount** | **Long** | Category percentage of the entire route. |  [optional]



