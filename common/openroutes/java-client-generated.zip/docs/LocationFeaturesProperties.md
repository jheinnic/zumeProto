
# LocationFeaturesProperties

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**osmId** | **String** |  |  [optional]
**category** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**address** | **String** |  |  [optional]
**phone** | **String** |  |  [optional]
**website** | **String** |  |  [optional]
**openingHours** | **String** |  |  [optional]
**wheelchair** | **String** |  |  [optional]
**distance** | **String** |  |  [optional]



